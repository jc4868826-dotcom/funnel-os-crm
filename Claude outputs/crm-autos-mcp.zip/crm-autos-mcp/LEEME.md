# crm-autos-mcp (CRM RMG Autos / FunnelOS)
1. unzip en ~/crm-autos-mcp  2. npm install  3. registrar "crm-autos" en claude_desktop_config.json con env CRM_URL, CRM_USER, CRM_PASS, CRM_TENANT  4. Cmd+Q y reabrir Claude Desktop.
Escrituras permitidas: crear lead, nota, cambiar estado, reasignar. WhatsApp real solo con CRM_ALLOW_WHATSAPP=1.
Bitácora local: bitacora_escrituras.jsonl
