#!/usr/bin/env node
// Conector MCP: Claude <-> CRM RMG Autos (FunnelOS) v0.1, nov 2026
// Transporte stdio (Claude Desktop local). Solo HTTP contra el CRM; no toca sus archivos.
import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { z } from 'zod';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const BASE = (process.env.CRM_URL || 'https://body-elite-giftcards.onrender.com').replace(/\/$/, '');
const USER = process.env.CRM_USER;
const PASS = process.env.CRM_PASS;
const TENANT = process.env.CRM_TENANT || 'demo_automotora'; // tenant de RMG Autos
const ALLOW_WA = process.env.CRM_ALLOW_WHATSAPP === '1';   // enviar WhatsApp reales: apagado por defecto
const TIMEOUT_MS = 60000; // Render puede estar dormido
const HERE = path.dirname(fileURLToPath(import.meta.url));
const BITACORA = path.join(HERE, 'bitacora_escrituras.jsonl');

const STATUSES = ['Nuevo', 'En Proceso', 'Contactado', 'Calificado', 'Agendado', 'Reservado', 'Seguimiento', 'Negociación', 'Atendido', 'Cerrado', 'Abandonado', 'Perdido'];
const ABANDON = ['sin_respuesta', 'presupuesto', 'sin_stock', 'otra_marca', 'compro_otro_lado', 'no_calificaba', 'otro'];

// ───────────── Cliente HTTP (sesión por token X-Auth-Token) ─────────────
let token = null;

async function http(method, url, body, auth = true) {
  const headers = { 'Content-Type': 'application/json' };
  if (auth && token) headers['X-Auth-Token'] = token;
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), TIMEOUT_MS);
  try {
    const res = await fetch(BASE + url, {
      method, headers, signal: ctl.signal,
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    const text = await res.text();
    let data; try { data = text ? JSON.parse(text) : null; } catch { data = text; }
    return { status: res.status, data };
  } finally { clearTimeout(t); }
}

async function login() {
  if (!USER || !PASS) throw new Error('Faltan CRM_USER / CRM_PASS en la config del conector.');
  const r = await http('POST', '/api/auth/login', { username: USER, password: PASS, tenant: TENANT }, false);
  if (r.status !== 200 || !r.data?.token) {
    throw new Error(`Login falló (${r.status}): ${r.data?.error || JSON.stringify(r.data)}`);
  }
  token = r.data.token; // las sesiones del CRM viven en memoria: se pierden al reiniciar Render
}

// Lectura: solo rutas de consulta conocidas. Escritura: lista blanca estricta.
const READ_ALLOW = /^\/api\/(leads|pipeline|dashboard|analytics|config|inventory|precios|inspecciones|users|me|bot)(\/|\?|$)/;
const WRITE_ALLOW = [
  { method: 'POST', re: /^\/api\/leads\/manual$/ },
  { method: 'PATCH', re: /^\/api\/leads\/[\w-]+$/ },
  { method: 'POST', re: /^\/api\/leads\/[\w-]+\/reassign$/ },
  ...(ALLOW_WA ? [{ method: 'POST', re: /^\/api\/leads\/[\w-]+\/message$/ }] : []),
];

async function crm(method, url, body) {
  if (!url.startsWith('/api/')) throw new Error('Ruta no permitida');
  if (method === 'GET') {
    if (!READ_ALLOW.test(url)) throw new Error(`Lectura no permitida por el conector: ${url}`);
  } else if (!WRITE_ALLOW.some(w => w.method === method && w.re.test(url))) {
    throw new Error(`Escritura bloqueada por el conector: ${method} ${url}`);
  }
  if (!token) await login();
  const run = async () => {
    let r = await http(method, url, body);
    if (r.status === 401) { await login(); r = await http(method, url, body); }
    return r;
  };
  let r;
  try { r = await run(); }
  catch (e) { if (method !== 'GET') throw e; r = await run(); } // reintento único solo en lecturas
  if (r.status >= 400) throw new Error(`CRM ${r.status}: ${r.data?.error || JSON.stringify(r.data)}`);
  return r.data;
}

const qs = (o) => {
  const p = new URLSearchParams();
  for (const [k, v] of Object.entries(o)) if (v !== undefined && v !== null && v !== '') p.set(k, String(v));
  const s = p.toString();
  return s ? `?${s}` : '';
};
const norm = (s) => String(s ?? '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
const ok = (obj) => ({ content: [{ type: 'text', text: typeof obj === 'string' ? obj : JSON.stringify(obj, null, 2) }] });
const fail = (e) => ({ isError: true, content: [{ type: 'text', text: `Error: ${e.message}` }] });
const safe = (fn) => async (args) => { try { return ok(await fn(args || {})); } catch (e) { return fail(e); } };
const fecha = (ts) => ts ? new Date(ts).toLocaleString('es-CL', { timeZone: 'America/Santiago' }) : null;

function bitacora(entry) {
  try { fs.appendFileSync(BITACORA, JSON.stringify({ ts: new Date().toISOString(), tenant: TENANT, usuario: USER, ...entry }) + '\n'); } catch { /* no bloquea */ }
}

// Resumen compacto de un lead (sin chat ni media, que pesan mucho)
const resumen = (l) => ({
  id: l.id, nombre: l.name, telefono: l.phone, canal: l.source, interes: l.interest,
  estado: l.status, vendedor: l.assignedTo, sla: l.alertLevel, bot_activo: !!l.botActive,
  sin_leer: !!l.unread, compra_rmg: !!l.isCompraRmg,
  creado: fecha(l.createdAt || l.id), ultima_interaccion: fecha(l.lastInteraction),
  proxima_accion: l.nextAction?.text || null,
});

// ───────────── Servidor MCP ─────────────
const server = new McpServer({ name: 'crm-autos', version: '0.1.0' });
const L = z.number().int().min(1).max(200).default(30).describe('Máximo de filas (1-200)');

// ——— Lectura ———
server.tool('crm_leads',
  'Lista leads del CRM de RMG Autos (resumen). Filtros: estado, vendedor, canal, texto, rango de fechas YYYY-MM-DD. mode=gestion filtra por actividad en el rango en vez de fecha de creación.',
  {
    estado: z.string().optional().describe('Ej: Nuevo, Calificado, Agendado, Reservado, Cerrado, Abandonado'),
    vendedor: z.string().optional().describe('username del vendedor asignado'),
    canal: z.string().optional().describe('Ej: Meta Ads, Chileautos, Instagram, Landing Page'),
    q: z.string().optional().describe('Texto en nombre, teléfono o interés'),
    desde: z.string().optional(), hasta: z.string().optional(),
    mode: z.enum(['creados', 'gestion']).default('creados'),
    limite: L,
  },
  safe(async ({ estado, vendedor, canal, q, desde, hasta, mode, limite }) => {
    const data = await crm('GET', '/api/leads' + qs({ start: desde, end: hasta, mode: mode === 'gestion' ? 'gestion' : undefined, seller: vendedor }));
    let rows = Array.isArray(data) ? data : [];
    if (estado) rows = rows.filter(l => norm(l.status) === norm(estado));
    if (vendedor) rows = rows.filter(l => l.assignedTo === vendedor);
    if (canal) rows = rows.filter(l => norm(l.source).includes(norm(canal)));
    if (q) { const n = norm(q); rows = rows.filter(l => [l.name, l.phone, l.interest].some(v => norm(v).includes(n))); }
    return { total: rows.length, mostrando: Math.min(limite, rows.length), leads: rows.slice(0, limite).map(resumen) };
  }));

server.tool('crm_lead_detalle',
  'Detalle de un lead: datos, notas, próxima acción y últimos mensajes del chat.',
  { id: z.string(), ultimos_mensajes: z.number().int().min(0).max(100).default(15) },
  safe(async ({ id, ultimos_mensajes }) => {
    const l = await crm('GET', `/api/leads/${encodeURIComponent(id)}`);
    const chat = Array.isArray(l.chatHistory) ? l.chatHistory : [];
    const { chatHistory, media, ...resto } = l;
    return {
      ...resto,
      notes: (l.notes || []).map(n => ({ autor: n.author, fecha: fecha(n.ts), texto: n.content })),
      chat_total: chat.length,
      chat_ultimos: chat.slice(-ultimos_mensajes).map(m => ({ de: m.role === 'user' ? 'cliente' : (m.agentName || m.role), fecha: fecha(m.ts), texto: m.content })),
      media_total: Array.isArray(media) ? media.length : 0,
    };
  }));

server.tool('crm_pipeline',
  'Embudo (Kanban): cantidad de leads por etapa y los más recientes de cada una.',
  { desde: z.string().optional(), hasta: z.string().optional(), vendedor: z.string().optional(), por_etapa: z.number().int().min(0).max(20).default(5) },
  safe(async ({ desde, hasta, vendedor, por_etapa }) => {
    const data = await crm('GET', '/api/pipeline' + qs({ start: desde, end: hasta, seller: vendedor }));
    return (data || []).map(c => ({ etapa: c.stage, total: c.leads.length, recientes: c.leads.slice(0, por_etapa).map(resumen) }));
  }));

server.tool('crm_kpis',
  'KPIs generales del CRM (requiere usuario admin/supervisor): total, activos, cerrados, SLA, conversión, tiempos de respuesta.',
  { desde: z.string().optional(), hasta: z.string().optional() },
  safe(async ({ desde, hasta }) => crm('GET', '/api/dashboard/kpis' + qs({ start: desde, end: hasta }))));

server.tool('crm_equipo',
  'Desempeño por vendedor: leads, SLA, cierres, conversión y tiempo de respuesta (requiere admin/supervisor).',
  { desde: z.string().optional(), hasta: z.string().optional() },
  safe(async ({ desde, hasta }) => crm('GET', '/api/dashboard/team' + qs({ start: desde, end: hasta }))));

server.tool('crm_canales',
  'Analítica por canal de origen (Meta Ads, Google Ads, Instagram, Chileautos, Landing, Referido): leads y conversión (requiere admin/supervisor).',
  { desde: z.string().optional(), hasta: z.string().optional(), vendedor: z.string().optional() },
  safe(async ({ desde, hasta, vendedor }) => crm('GET', '/api/analytics/channels' + qs({ start: desde, end: hasta, seller: vendedor }))));

server.tool('crm_inventario',
  'Inventario de vehículos del CRM. Busca por texto (marca, modelo, año).',
  { q: z.string().optional(), limite: L },
  safe(async ({ q, limite }) => {
    const data = await crm('GET', '/api/inventory');
    let rows = Array.isArray(data) ? data : (data?.items || []);
    if (q) { const n = norm(q); rows = rows.filter(v => norm(JSON.stringify(v)).includes(n)); }
    return { total: rows.length, mostrando: Math.min(limite, rows.length), autos: rows.slice(0, limite) };
  }));

server.tool('crm_equipo_usuarios',
  'Usuarios del CRM (nombre, rol, estado). Útil para saber a quién asignar un lead.',
  {}, safe(async () => {
    const u = await crm('GET', '/api/users');
    return (u || []).map(x => ({ username: x.username, nombre: x.name, rol: x.role, estado: x.status }));
  }));

server.tool('crm_config',
  'Configuración del CRM: etapas del embudo, canales y datos del negocio.',
  {}, safe(async () => crm('GET', '/api/config')));

server.tool('crm_consulta_lectura',
  'Consulta GET libre a rutas de consulta del CRM (leads, pipeline, dashboard, analytics, config, inventory, precios, inspecciones, users). Solo lectura.',
  { ruta: z.string().describe('Ej: /api/precios/mercado'), params: z.record(z.string()).optional() },
  safe(async ({ ruta, params }) => {
    const d = await crm('GET', ruta + qs(params || {}));
    const s = JSON.stringify(d);
    return s.length > 60000 ? { aviso: 'Resultado recortado (muy grande)', parcial: s.slice(0, 60000) } : d;
  }));

// ——— Escritura (dos pasos: vista previa → confirmar) ———
async function verificar(id) {
  try { const l = await crm('GET', `/api/leads/${encodeURIComponent(id)}`); return resumen(l); } catch { return null; }
}

server.tool('crm_crear_lead',
  'Crea un lead manual. OJO: si trae teléfono, el CRM envía de inmediato la plantilla de WhatsApp "saludo1" al cliente y avisa al vendedor asignado. Dos pasos: vista previa y luego confirmar=true con el "sí" del usuario.',
  {
    nombre: z.string().min(2),
    phone: z.string().optional().describe('Con código de país, ej 56912345678. Sin teléfono no se envía WhatsApp'),
    canal: z.string().default('WhatsApp'),
    asignado: z.string().optional().describe('username del vendedor; por defecto el usuario del conector'),
    interes: z.string().optional().describe('Vehículo o interés'),
    nota: z.string().optional(),
    status: z.enum(STATUSES).default('Nuevo'),
    compra_rmg: z.boolean().default(false).describe('true si es compra de auto a un cliente (Compramos tu Auto)'),
    confirmar: z.boolean().default(false),
  },
  safe(async (a) => {
    const payload = {
      nombre: a.nombre, phone: a.phone || 'Pendiente', canal: a.canal, asignado: a.asignado,
      interes: a.interes || '', nota: a.nota || '', status: a.status, isCompraRmg: a.compra_rmg,
    };
    const envia_wa = payload.phone !== 'Pendiente';
    if (!a.confirmar) {
      return {
        vista_previa: payload,
        efectos: [envia_wa ? 'Se enviará la plantilla de WhatsApp "saludo1" a ese teléfono (si el CRM tiene WhatsApp configurado)' : 'Sin teléfono: no se envía WhatsApp', 'Se avisará al vendedor asignado'],
        aviso: 'NO creado. Pide confirmación al usuario y vuelve a llamar con confirmar=true.',
      };
    }
    const r = await crm('POST', '/api/leads/manual', payload);
    bitacora({ accion: 'lead.crear', payload, leadId: r?.leadId });
    return { creado: r, verificado: r?.leadId ? await verificar(r.leadId) : null };
  }));

server.tool('crm_agregar_nota',
  'Agrega una nota interna a un lead. Efecto colateral del CRM: cuenta como gestión (actualiza última interacción y reinicia el semáforo SLA). Dos pasos: vista previa y confirmar=true.',
  { id: z.string(), nota: z.string().min(2), confirmar: z.boolean().default(false) },
  safe(async ({ id, nota, confirmar }) => {
    const antes = await verificar(id);
    if (!confirmar) return { vista_previa: { lead: antes, nota }, aviso: 'NO guardada. Pide confirmación y vuelve a llamar con confirmar=true.' };
    await crm('PATCH', `/api/leads/${encodeURIComponent(id)}`, { note: nota });
    bitacora({ accion: 'lead.nota', leadId: id, nota });
    return { guardada: true, lead: await verificar(id) };
  }));

server.tool('crm_cambiar_estado',
  `Cambia la etapa de un lead. Para "Abandonado" es obligatorio el motivo (${ABANDON.join(', ')}). Dos pasos: vista previa y confirmar=true.`,
  {
    id: z.string(), status: z.enum(STATUSES),
    motivo_abandono: z.enum(ABANDON).optional(),
    nota: z.string().optional(),
    confirmar: z.boolean().default(false),
  },
  safe(async ({ id, status, motivo_abandono, nota, confirmar }) => {
    if (status === 'Abandonado' && !motivo_abandono) throw new Error('Para Abandonado indica motivo_abandono');
    const antes = await verificar(id);
    const payload = { status, abandonReason: status === 'Abandonado' ? motivo_abandono : undefined, note: nota };
    if (!confirmar) return { vista_previa: { lead: antes, cambio: `${antes?.estado} → ${status}`, ...payload }, aviso: 'NO cambiado. Pide confirmación y vuelve a llamar con confirmar=true.' };
    await crm('PATCH', `/api/leads/${encodeURIComponent(id)}`, payload);
    bitacora({ accion: 'lead.estado', leadId: id, de: antes?.estado, a: status, motivo_abandono });
    return { cambiado: true, lead: await verificar(id) };
  }));

server.tool('crm_reasignar_lead',
  'Reasigna un lead a otro vendedor (requiere permiso de reasignación en el usuario del conector). Dos pasos: vista previa y confirmar=true.',
  { id: z.string(), a: z.string().describe('username del vendedor destino'), confirmar: z.boolean().default(false) },
  safe(async ({ id, a, confirmar }) => {
    const antes = await verificar(id);
    if (!confirmar) return { vista_previa: { lead: antes, de: antes?.vendedor, a }, aviso: 'NO reasignado. Pide confirmación y vuelve a llamar con confirmar=true.' };
    await crm('POST', `/api/leads/${encodeURIComponent(id)}/reassign`, { to: a });
    bitacora({ accion: 'lead.reasignar', leadId: id, de: antes?.vendedor, a });
    return { reasignado: true, lead: await verificar(id) };
  }));

if (ALLOW_WA) {
  server.tool('crm_enviar_whatsapp',
    'ENVÍA UN WHATSAPP REAL al cliente del lead y lo deja en el chat. Dos pasos: vista previa y luego confirmar=true solo con el "sí" explícito del usuario al texto exacto.',
    { id: z.string(), texto: z.string().min(2), confirmar: z.boolean().default(false) },
    safe(async ({ id, texto, confirmar }) => {
      const antes = await verificar(id);
      if (!confirmar) return { vista_previa: { para: antes, texto }, aviso: 'NO enviado. Se enviará un WhatsApp real. Pide confirmación del texto exacto y vuelve a llamar con confirmar=true.' };
      await crm('POST', `/api/leads/${encodeURIComponent(id)}/message`, { content: texto });
      bitacora({ accion: 'lead.whatsapp', leadId: id, texto });
      return { enviado: true, lead: await verificar(id) };
    }));
}

await server.connect(new StdioServerTransport());
